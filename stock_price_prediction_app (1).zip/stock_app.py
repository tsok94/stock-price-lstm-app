import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

st.title("📊 Stock Price Prediction App")

# User inputs
stock_symbol = st.text_input("Enter stock symbol (e.g., AAPL, RELIANCE.NS):", value='AAPL')
start_date = st.date_input("Start Date", pd.to_datetime('2020-01-01'))
end_date = st.date_input("End Date", pd.to_datetime('2024-12-31'))

if st.button("Get Stock Data"):
    data = yf.download(stock_symbol, start=start_date, end=end_date)

    if data.empty:
        st.error("No data found for this symbol and date range.")
    else:
        data = data[['Open', 'High', 'Low', 'Close', 'Volume']]
        data.dropna(inplace=True)

        # Show raw data
        st.subheader("Raw Stock Data")
        st.dataframe(data.tail())

        # Line chart for closing prices
        st.subheader("📈 Closing Price Trend")
        st.line_chart(data['Close'])

        # Bar chart for volume
        st.subheader("📊 Trading Volume")
        st.bar_chart(data['Volume'])

        # Prepare features and target
        X = data[['Open', 'High', 'Low', 'Volume']]
        y = data['Close']

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

        # Train model
        model = LinearRegression()
        model.fit(X_train, y_train)

        # Predict
        predictions = model.predict(X_test)
        mse = mean_squared_error(y_test, predictions)
        st.write("Mean Squared Error:", round(mse, 2))

        # Plot actual vs predicted
        st.subheader("📉 Actual vs Predicted Prices")
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(y_test.values, label='Actual Price')
        ax.plot(predictions, label='Predicted Price')
        ax.set_title(f"{stock_symbol} - Actual vs Predicted")
        ax.set_xlabel("Index")
        ax.set_ylabel("Price")
        ax.legend()
        st.pyplot(fig)
