# 📊 Stock Price Prediction Web App

## Features
- Enter stock symbol (e.g., AAPL, RELIANCE.NS)
- Fetch stock data from Yahoo Finance
- View closing price and trading volume charts
- Predict closing prices using Linear Regression
- Show Mean Squared Error and plot predicted vs actual prices

## How to Run

1. Install required libraries:
```
pip install -r requirements.txt
```

2. Run the app:
```
streamlit run stock_app.py
```
